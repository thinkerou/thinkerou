package com.example.demo;

import org.pac4j.core.profile.ProfileManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest/n/user")
public class UserController {

    @Autowired
    private ProfileManager profileManager;

    @RequestMapping("/info")
    public ResponseEntity info() {
        System.out.println(profileManager.get(true).toString());
        return new ResponseEntity(profileManager.getAll(true), HttpStatus.OK);
    }

}
