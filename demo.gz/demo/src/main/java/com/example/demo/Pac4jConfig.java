package com.example.demo;

import org.pac4j.cas.client.CasClient;
import org.pac4j.cas.config.CasConfiguration;
import org.pac4j.core.client.Clients;
import org.pac4j.core.config.Config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Pac4jConfig {

    @Value("${cas.server.url}")
    private String casServerUrl;

    @Value("${cas.project.url}")
    private String projectUrl;

    @Bean
    public Config config() {
        final CasConfiguration config = new CasConfiguration(casServerUrl + "/login");
        final CasClient casClient = new CasClient(config);

        final Clients clients = new Clients(projectUrl + "/callback", casClient);
        return new Config(clients);
    }

}
